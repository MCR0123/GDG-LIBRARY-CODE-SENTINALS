// node --version # Should be >= 18
// npm install @google/generative-ai

const {
    GoogleGenerativeAI,
    HarmCategory,
    HarmBlockThreshold,
  } = require("@google/generative-ai");
  
  const MODEL_NAME = "gemini-1.5-pro-latest";
  const API_KEY = "AIzaSyAJv7COcep-4xuQvS4A03MHwyLn0U0qXow";
  
  async function runChat(userInput) {
    const genAI = new GoogleGenerativeAI(API_KEY);
    const model = genAI.getGenerativeModel({ model: MODEL_NAME });
  
    const generationConfig = {
      temperature: 1,
      topK: 0,
      topP: 0.95,
      maxOutputTokens: 8192,
    };
  
    const safetySettings = [
      {
        category: HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
      },
      {
        category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
      },
      {
        category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
      },
      {
        category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
      },
    ];
  
    const chat = model.startChat({
      generationConfig,
      safetySettings,
      history: [
        {
          role: "user",
          parts: [{ text: userInput }],
        },
        {
          role: "model",
          parts: [{ text: "json\n{\n  \"instructions\": \"Please input the ISBN number of the textbook you need:\",\n  \"input_field\": \"isbn_input\",\n  \"submit_button\": \"search_button\",\n  \"error_message\": \"Invalid ISBN. Please try again.\",\n  \"results\": {\n    \"9780321982384\": {\n      \"title\": \"Introduction to Java Programming\",\n      \"author\": \"Y. Daniel Liang\",\n      \"edition\": \"11th\",\n      \"download_link\": \"https://www.liang.com/intro-java/11e/index.html\" \n    },\n    \"9780134685991\": {\n      \"title\": \"Starting Out with Python\",\n      \"author\": \"Tony Gaddis\",\n      \"edition\": \"5th\",\n      \"download_link\": \"https://www.pearson.com/us/higher-education/program/Gaddis-Starting-Out-with-Python-5th-Edition/PGM337441.html\" \n    } \n    // Add more ISBN entries as needed\n  }\n}\n"}],
        },
        {
          role: "user",
          parts: [{ text: userInput }], // Change this to userInput
        },
        {
          role: "model",
          parts: [{ text: "Write up an API with regards to the previous prompt" }],
        },
      ],
    });
  
    const result = await chat.sendMessage(userInput); // Accepting userInput as an argument
    const response = result.response;
    console.log(response.text());
  }
  
  // Accepting user input as a command line argument
  const userInput = process.argv[2];
  runChat(userInput);
  